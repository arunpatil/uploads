import os
import time
import signal
import psutil
import subprocess
import watchdog.events
from watchdog.observers import Observer
from os import path
import tarfile
import time

update_path = "/home/pi/pulse/update/"
failsafe_path = "/home/pi/pulse/failsafe/"
exe_path = "/home/pi/pulse/"
exe_name = "pulse"
failsafe_archive = "/home/pi/pulse/failsafe/failsafe.tar.gz"
factory_archive = "/home/pi/pulse/factory/factory.tar.gz"
service_name = "pulse"
observer = 0
isUpdating = False
isFWReceived = False
isKbdExit = False
retryCount=0
failsafeRestored=False

def findProcessIdByName(processName):
	listOfProcessObjects = []
	#Iterate over the all the running process
	for proc in psutil.process_iter():
		try:
			pinfo = proc.as_dict(attrs=['pid', 'name', 'create_time'])

			if processName.lower() in pinfo['name'].lower() :
				listOfProcessObjects.append(pinfo)
		except (psutil.NoSuchProcess, psutil.AccessDenied , psutil.ZombieProcess) :
			pass
	return listOfProcessObjects;

def waitForProcess(processName):
	try:
		while True:
			listOfProcessIds = findProcessIdByName(processName)
			if len(listOfProcessIds) > 0:
				continue
			else:
				break
			time.sleep(3)
	except:
		print("Exception occurred in waitForProcess")

def killRunningProcesses():
	#os.system("clear")
	
	listOfProcessIds = findProcessIdByName(exe_name)
	
	if len(listOfProcessIds) > 0:
		print('Process Exists | PID and other details are')
		for elem in listOfProcessIds:
			processID = elem['pid']
			processName = elem['name']
			processCreationTime =  time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(elem['create_time']))
			print((processID ,processName,processCreationTime ))
			os.system("sudo pkill " + processName)
			waitForProcess(processName)
	else :
		print('No Running Process found with given text')
	
	print("-------------------------------------")

def copyServiceFile():
	isServiceFileAvailable = path.exists(exe_path + service_name + ".service")
	if(isServiceFileAvailable==True):
		os.system("sudo systemctl disable " + service_name + ".service")
		os.system("sudo cp " + exe_path + service_name + ".service /etc/systemd/system/" + service_name + ".service")
		os.system("sudo systemctl enable " + service_name + ".service")
		os.remove(exe_path + service_name + ".service")

def failsafeBackup(filename):
	try:
		print("Creating failsafe firmware backup")
		tar = tarfile.open(filename, "w:gz")
		for fname in os.listdir(exe_path):
			print(fname)
			if os.path.isfile(fname):
				tar.add(fname)
		tar.close()
		return 1
	except:
		print("Exception occurred in failsafe backup firmware")
	return 0
	
def failsafeRestore(filename):
	try:
		print("Restoring failsafe firmware")
		tar = tarfile.open(filename, "r:gz")
		tar.extractall()
		tar.close()
	except:
		print("Exception occurred in failsafe restore firmware")

def createFactoryImage():
	isFileAvailable = path.exists(factory_archive)
	if(isFileAvailable==False):
		failsafeBackup(factory_archive)
	

def extractNCopyFiles():
	try:
		backedUp = 0
		for fname in os.listdir(update_path):
			if backedUp==0:
				backedUp=failsafeBackup(failsafe_archive)
				if backedUp==0:
					break
				else:
					#os.system("sudo rm -f " + exe_path + "*")
					isFWReceived=True
					
			if fname.endswith("tar.gz") or fname.endswith("tgz"):
				tar = tarfile.open(update_path+fname, "r:gz")
				tar.extractall()
				tar.close()
			elif fname.endswith("tar"):
				tar = tarfile.open(update_path+fname, "r:")
				tar.extractall()
				tar.close()
			os.remove(update_path+fname)
	except:
		print("Exception while copying firmware")
		os.system("sudo rm -rf " + update_path + "*")
		failsafeRestore(failsafe_archive)
	os.system("sudo chmod +x " + exe_path + exe_name)

def startHandler():

	class MyHandler(watchdog.events.PatternMatchingEventHandler):
		def __init__(self):
			watchdog.events.PatternMatchingEventHandler.__init__(self, patterns=['*.gz', '*.tgz'],ignore_directories=True, case_sensitive=False)
			
		def on_created(self, event):
			global isUpdating
			isUpdating = True
			historicalSize = -1
			while (historicalSize != os.path.getsize(event.src_path)):
				historicalSize = os.path.getsize(event.src_path)
				time.sleep(5)
			killRunningProcesses()
			extractNCopyFiles()
			copyServiceFile()
			isUpdating = False
						
	global observer
	event_handler = MyHandler()
	observer = Observer()
	observer.schedule(event_handler, path=update_path, recursive=False)
	observer.start()
	
def startProcess():
	try:
		ret = os.system("sudo "+ exe_path + exe_name)
	except:
		print ("Start process failed ")

killRunningProcesses()
extractNCopyFiles()
createFactoryImage()
copyServiceFile()
startHandler()

try:
	while True:
		global isUpdating
		global isKbdExit
		if isUpdating==True:
			time.sleep(1)
			retryCount = 0
		elif isKbdExit==True:
			break
		else:
			beforeStart = time.time()
			startProcess()
			afterExit = time.time()
			timeDifference = int(afterExit - beforeStart)
			if timeDifference < 60:
				retryCount = retryCount + 1
			else:
				retryCount = 0
				isFWReceived=False
				failsafeRestored=False
			time.sleep(1)	#in case the application breaks, restart after 1 second
			
			if retryCount > 6:
				time.sleep(5)	# worst case, keep listening for updates until you manually reboot
			elif retryCount > 4 and isFWReceived==True and failsafeRestored==True:
				#failsafeRestore(factory_archive)
				os.system("sudo reboot")	# Reboot if failsafe also fails to load
			elif retryCount > 2 and isFWReceived==True and failsafeRestored==False:
				failsafeRestore(failsafe_archive)
				failsafeRestored = True
				
except KeyboardInterrupt:
	global observer
	observer.stop()
	global isKbdExit
	isKbdExit = True
	
print("\r\nExiting Main Python Function")

